public class B {

    private int f = 1;

    private byte c = 1;

    public long dd() {
        return 99999;
    }

    public int ae() {
        return java.lang.Math.abs(-7);
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }
}
