public class K extends A {

    private long d = 4321;

    private double e = 100.500;

    public float ff() {
        return 0;
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public Object pp() {
        return this;
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public int cc() {
        return 13;
    }

    public int ae() {
        return 9;
    }

    public void bb() {
        System.out.println(42);
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public String kk() {
        return "Hello world";
    }

    public long ac() {
        return 333;
    }

    public void ab() {
        System.out.println("\n");
    }
}
