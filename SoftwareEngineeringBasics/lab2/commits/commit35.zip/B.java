public class B extends null {

    private int f = 1;

    private byte c = 1;

    public long dd() {
        return 99999;
    }

    public int ae() {
        return java.lang.Math.abs(-7);
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public void ab() {
        System.out.println("\n");
    }

    public float ff() {
        return 3.14;
    }

    public void bb() {
        System.out.println(42);
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public int af() {
        return -1;
    }

    public byte oo() {
        return 3;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public long ac() {
        return 111;
    }

    public int cc() {
        return 13;
    }

    public Object rr() {
        return null;
    }

    public Object pp() {
        return this;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public double ee() {
        return 0.000001;
    }
}
