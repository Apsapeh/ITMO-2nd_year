public class A extends null implements D {

    private long k = 1234;

    private int j = 1;

    public Object rr() {
        return null;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public int af() {
        return -1;
    }

    public byte oo() {
        return 4;
    }

    public void ab() {
        System.out.println("\n");
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public String kk() {
        return "No";
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public int cc() {
        return 13;
    }

    public long dd() {
        return 99999;
    }

    public Object pp() {
        return this;
    }

    public void bb() {
        System.out.println(42);
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public double ee() {
        return 500.100;
    }

    public float ff() {
        return 0;
    }
}
