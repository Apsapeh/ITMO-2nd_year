public class D extends null {

    int af();

    byte oo();
}
