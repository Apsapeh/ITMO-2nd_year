public interface D {

    int af();

    byte oo();
}
