public class D extends null {

    int af();

    byte oo();

    public void aa() {
        return;
    }

    public Object pp() {
        return this;
    }

    public int ae() {
        return 9;
    }
}
