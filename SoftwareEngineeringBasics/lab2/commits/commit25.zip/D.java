public class D extends null {

    int af();

    byte oo();

    public Object pp() {
        return this;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }
}
