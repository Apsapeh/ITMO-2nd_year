public class K extends A {

    private long d = 4321;

    private double e = 100.500;

    public float ff() {
        return 0;
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public Object pp() {
        return this;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }
}
